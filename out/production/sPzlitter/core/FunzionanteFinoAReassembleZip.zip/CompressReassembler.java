package core;

import java.io.*;
import java.util.Arrays;
import java.util.zip.Inflater;

public class CompressReassembler extends Reassembler {

    public CompressReassembler(File file) { super(file); }

    String[] bufferLenght;
    int index =0;

    @Override
    protected void beforeReassemble() {
        try {
            File f = new File("/Users/infopz/Documents/IdeaProject/sPzlitter/Output/prova.txt.metadata.PROTECTME");
            FileInputStream i = new FileInputStream(f.getAbsolutePath());
            ObjectInputStream io = new ObjectInputStream(i);

            String buffLenght = (String) io.readObject();
            bufferLenght = buffLenght.split(";");

            io.close();
            i.close();

            System.out.println(buffLenght);
        } catch (Exception e){
            e.printStackTrace();
        }

    }

    @Override
    protected byte[] processBytes(byte[] b) {
        try {
            System.out.println("in " + b.length);
            Inflater decompresser = new Inflater();
            decompresser.setInput(b, 0, b.length);
            //FIXME: cambiare la dimensione
            byte[] result = new byte[15000];
            int resultLength = decompresser.inflate(result);
            decompresser.end();
            result = Arrays.copyOfRange(result, 0, resultLength);
            System.out.println(resultLength);
            return result;
        } catch (Exception e){
            e.printStackTrace();
        }
        return b;
    }
}
