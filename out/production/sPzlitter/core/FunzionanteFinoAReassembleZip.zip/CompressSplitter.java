package core;

import java.io.*;
import java.util.Arrays;
import java.util.zip.*;

public class CompressSplitter extends Splitter {

    private String buffersDimensions = "";

    public CompressSplitter(File f) { super(f); }

    @Override
    protected byte[] processBytes(byte[] b) {
        // Prepara il buffer
        byte[] output = new byte[b.length];
        // Crea l'oggetto compressore e lo imposta
        Deflater compresser = new Deflater();
        compresser.setInput(b);
        compresser.finish();
        // Comprime i byte
        int compressedDataLength = compresser.deflate(output);
        compresser.end();
        // Li restituisce
        byte[] data = Arrays.copyOfRange(output, 0, compressedDataLength);

        buffersDimensions = buffersDimensions + compressedDataLength + ";";

        //String metadataString = compressedDataLength + "pz";
        //byte[] metadata = metadataString.getBytes();
        //byte[] toWrite = new byte[data.length + metadata.length];
        //System.arraycopy(metadata, 0 , toWrite, 0, metadata.length);
        //System.arraycopy(data, 0, toWrite, metadata.length, data.length);
        return data;
    }

    @Override
    protected void afterSplitting(){
        try {

            // Salva su un file la chiave di cifratura
            File keyFile = new File(Utils.getDirectory(file), file.getName() + ".metadata.PROTECTME");
            FileOutputStream o = new FileOutputStream(keyFile.getAbsolutePath());
            ObjectOutputStream os = new ObjectOutputStream(o);

            os.writeObject(buffersDimensions);

            os.close();
            o.close();

        } catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    protected void writeMetadata(FileOutputStream o, int currentPart) {
        try {
            String metadata = String.format("%03d", currentPart) + String.format("%03d", nParts) + "10";
            o.write(metadata.getBytes());
        } catch (Exception e){
            e.printStackTrace();
        }
    }
}
