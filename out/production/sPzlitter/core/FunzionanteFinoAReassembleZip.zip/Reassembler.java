package core;

import java.io.*;
import java.util.Arrays;

public class Reassembler {

    protected File file;

    final int BUFFER_SIZE = 4096;
    final int METADATA_SIZE = 8;

    public Reassembler(File f){ file = f; }
    // TODO: Fare controlli, nel costruttore???

    public void reassemble(){
        try {

            beforeReassemble();

            // Apre il file
            FileInputStream i = new FileInputStream(file);

            // Legge i metadati
            byte[] metadataBytes = new byte[METADATA_SIZE];
            i.read(metadataBytes, 0, METADATA_SIZE);
            int totalParts = Integer.parseInt(new String(Arrays.copyOfRange(metadataBytes,3,6)));

            // Chiude il file
            i.close();

            String path = file.getAbsolutePath();
            String partsPath = path.substring(0, path.length() - 1);

            // TODO: Farlo ritornare al nome originale
            File out = new File(Utils.getDirectory(file), "output");
            FileOutputStream o = new FileOutputStream(out);

            for(int j=0; j<totalParts; j++){
                File part = new File(partsPath + j);
                i = new FileInputStream(part);

                // Remove metadata
                i.skip(8);

                int partDimension = (int) part.length() - METADATA_SIZE;
                for(int bytesRemaned = partDimension; bytesRemaned>0; bytesRemaned = bytesRemaned - BUFFER_SIZE){
                    int currentRead = BUFFER_SIZE;
                    if (bytesRemaned<BUFFER_SIZE) currentRead = bytesRemaned;

                    byte[] data = new byte[currentRead];
                    i.read(data, 0, currentRead);
                    data = processBytes(data);
                    o.write(data, 0 , currentRead);
                }
                i.close();
            }
            o.close();

            afterReassemble();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected void beforeReassemble() {}
    protected byte[] processBytes(byte[] b) { return b; }
    protected void afterReassemble() {}
}
